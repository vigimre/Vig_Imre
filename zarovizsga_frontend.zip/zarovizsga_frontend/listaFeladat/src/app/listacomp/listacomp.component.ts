import { CommonModule, NgFor } from '@angular/common';
import { Component, Output } from '@angular/core';

@Component({
  selector: 'app-listacomp',
  imports: [CommonModule],
  templateUrl: './listacomp.component.html' ,
  styleUrl: './listacomp.component.css'
})
export class ListacompComponent {
 @Output() elemek: string[] = ["Elem1", "Elem2", "Elem3"];
}


